[app]

title = TPV Ultra Smart
package.name = tpvultrasmart
package.domain = com.universidad.tpv
version = 1.0

source.dir = .
source.main = main.py

# Archivos y carpetas a incluir (esto era el problema principal)
source.include_exts = py,png,jpg,jpeg,kv,atlas,json,html,css,js,xml,ttf,woff,woff2
source.include_patterns = frontend/**,backend/**,database/**,config/**,logs/**

source.exclude_patterns = .buildozer/*,bin/*,*.pyc,__pycache__/*,compilacion/*,*.backup

requirements = python3,kivy==2.3.0,flask==2.2.5,werkzeug==2.2.3,requests,urllib3,pyjnius

orientation = portrait
fullscreen = 0

android.permissions = INTERNET,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE
android.request_legacy_external_storage = True
android.extra_manifest_application_arguments = android:networkSecurityConfig="@xml/network_security_config"

android.minapi = 21
android.api = 33
android.archs = arm64-v8a,armeabi-v7a

p4a.branch = master

[buildozer]
log_level = 2
warn_on_root = 1

android_uses_cleartext_traffic = True
